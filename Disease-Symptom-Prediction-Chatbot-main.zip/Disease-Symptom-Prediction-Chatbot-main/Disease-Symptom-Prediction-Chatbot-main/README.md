# ROBO-DOC
Healthcare chatbot to predict Diseases based on patient symptoms.
<br>
<p align="center">
  <img src="screens\prediction.png" width="500" >
</p>

Medical DataSet available !!
---- 
